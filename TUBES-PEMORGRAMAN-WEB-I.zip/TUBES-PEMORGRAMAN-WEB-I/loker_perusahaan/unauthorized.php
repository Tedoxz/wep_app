<!DOCTYPE html>
<html>
<head><title>Akses Ditolak</title></head>
<body>
    <h2>Anda tidak memiliki akses ke halaman ini.</h2>
    <a href="../auth/login.php">Kembali ke Login</a>
</body>
</html>

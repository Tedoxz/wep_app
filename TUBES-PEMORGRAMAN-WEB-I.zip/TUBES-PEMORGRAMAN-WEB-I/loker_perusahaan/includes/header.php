<!DOCTYPE html>
<html>
<head>
    <title>Loker Perusahaan</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        nav a { margin-right: 15px; text-decoration: none; }
    </style>
</head>
<body>
<nav>
    <a href="../auth/logout.php">Logout</a>
    <a href="../pages/profil.php">Profil Perusahaan</a>
</nav>
<hr>

<hr>
<footer>
    <p>&copy; <?= date("Y") ?> Loker Perusahaan PT.XYZ</p>
</footer>
</body>
</html>

<?php

include '../config/koneksi.php';
include('../includes/auth/user.php');
include '../includes/header.php';


// Pastikan user login
if (!isset($_SESSION['id_user'])) {
    echo "Silakan login terlebih dahulu.";
    exit;
}

$id_user = $_SESSION['id_user'];

// Ambil id_pelamar dari user
$q_pelamar = mysqli_query($koneksi, "SELECT id_pelamar FROM pelamar WHERE id_user = $id_user");
$d_pelamar = mysqli_fetch_assoc($q_pelamar);

if (!$d_pelamar) {
    echo "Anda belum mengisi profil pelamar.";
    exit;
}

$id_pelamar = $d_pelamar['id_pelamar'];

// Ambil data lamaran
$query = "SELECT 
            l.id_lamar,
            lw.posisi,
            d.tanggal_mulai,
            d.tanggal_selesai,
            l.status
          FROM lamaran l
          JOIN detail_tahapan d ON l.id_detail = d.id_detail
          JOIN lowongan lw ON d.id_lowongan = lw.id_lowongan
          WHERE l.id_pelamar = $id_pelamar
          ORDER BY d.tanggal_mulai DESC";

$result = mysqli_query($koneksi, $query);
?>

<h2>Daftar Lamaran Saya</h2>
<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>No</th>
        <th>Lowongan</th>
        <th>Tanggal Seleksi</th>
        <th>Status</th>
    </tr>
    <?php
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>$no</td>";
        echo "<td>{$row['nama_lowongan']}</td>";
        echo "<td>{$row['tanggal_mulai']} s.d {$row['tanggal_selesai']}</td>";
        echo "<td><b>" . ucfirst($row['status']) . "</b></td>";
        echo "</tr>";
        $no++;
    }

    if ($no == 1) {
        echo "<tr><td colspan='4'>Belum ada lamaran.</td></tr>";
    }
    ?>
</table>
